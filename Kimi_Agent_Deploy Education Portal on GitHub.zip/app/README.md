# Borhan Sorkar Education Portal

A multilingual education platform featuring Islamic lectures, political analysis, and daily life wisdom from the YouTube channel **Mohammad Borhan Uddin Etc**.

![Website Preview](./preview.png)

## 🌐 Live Website

**[View Live Site](https://yourusername.github.io/borhan-sorkar-education/)**

## ✨ Features

- 🎨 **Modern Design** - Clean, professional UI with Bengali language support
- 📚 **Course Categories** - Organized playlists (Quran, Politics, Daily Life)
- 🎬 **YouTube Integration** - Embedded video player with playlist sidebar
- 📱 **Fully Responsive** - Works on all devices
- ⚡ **Fast Performance** - Built with Vite for optimal speed

## 🛠️ Tech Stack

- **React 18** - UI Library
- **TypeScript** - Type Safety
- **Vite** - Build Tool
- **Tailwind CSS** - Styling
- **shadcn/ui** - UI Components
- **Lucide React** - Icons

## 🚀 Getting Started

### Prerequisites

- Node.js 20+
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/borhan-sorkar-education.git
cd borhan-sorkar-education
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open [http://localhost:5173](http://localhost:5173) in your browser.

## 📦 Building for Production

```bash
npm run build
```

The built files will be in the `dist` folder.

## 🚀 Deploy to GitHub Pages

This project is configured for automatic deployment to GitHub Pages via GitHub Actions.

### Setup Instructions:

1. **Create a GitHub Repository**
   - Go to [GitHub](https://github.com)
   - Click "New Repository"
   - Name it: `borhan-sorkar-education`
   - Make it Public
   - Click "Create repository"

2. **Push Your Code**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/borhan-sorkar-education.git
   git push -u origin main
   ```

3. **Enable GitHub Pages**
   - Go to your repository on GitHub
   - Click **Settings** → **Pages**
   - Under "Source", select **GitHub Actions**
   - The workflow will automatically deploy your site

4. **Access Your Site**
   - After deployment, your site will be at:
   - `https://yourusername.github.io/borhan-sorkar-education/`

### Custom Domain (Optional)

To use a custom domain:

1. Create a file `public/CNAME` with your domain:
   ```
   www.yourdomain.com
   ```

2. Update `vite.config.ts`:
   ```ts
   base: '/',
   ```

3. Configure DNS settings with your domain provider

## 📁 Project Structure

```
├── .github/workflows/     # GitHub Actions for deployment
├── src/
│   ├── components/        # React components
│   ├── sections/          # Page sections
│   ├── App.tsx           # Main app component
│   ├── App.css           # App styles
│   └── index.css         # Global styles
├── dist/                 # Build output
├── index.html            # HTML entry point
├── vite.config.ts        # Vite configuration
├── tailwind.config.js    # Tailwind CSS config
└── package.json          # Dependencies
```

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 🙏 Credits

- **Channel**: [Mohammad Borhan Uddin Etc](https://youtube.com/@borhan_sorkar)
- **Design & Development**: Created with ❤️

---

**Made with ❤️ in Bangladesh**
