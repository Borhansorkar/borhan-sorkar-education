# 🚀 GitHub Pages Deployment Guide

Follow these simple steps to deploy your website to GitHub Pages for **FREE**!

---

## 📋 Prerequisites

1. A **GitHub account** (free to create at [github.com](https://github.com))
2. Your project files (already prepared)

---

## Step 1: Create a GitHub Repository

1. Go to [github.com](https://github.com) and sign in
2. Click the **"+"** icon in the top right → **"New repository"**
3. Fill in the details:
   - **Repository name**: `borhan-sorkar-education`
   - **Description**: Education portal for Borhan Sorkar YouTube channel
   - **Visibility**: Public (required for free GitHub Pages)
   - ✅ Check "Add a README file" (optional)
4. Click **"Create repository"**

---

## Step 2: Upload Your Project Files

### Option A: Using Git Command Line (Recommended)

Open your terminal/command prompt and run:

```bash
# Navigate to your project folder
cd /mnt/okcomputer/output/app

# Initialize Git repository
git init

# Add all files
git add .

# Commit the files
git commit -m "Initial commit - Borhan Sorkar Education Portal"

# Connect to GitHub (replace YOUR_USERNAME with your actual GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/borhan-sorkar-education.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### Option B: Using GitHub Website (Easier)

1. Go to your new repository on GitHub
2. Click **"Add file"** → **"Upload files"**
3. Drag and drop all files from `/mnt/okcomputer/output/app` folder
4. Click **"Commit changes"**

---

## Step 3: Enable GitHub Pages

1. In your repository, click **"Settings"** tab
2. Scroll down and click **"Pages"** in the left sidebar
3. Under **"Source"**, select:
   - **Deploy from a branch** → Change to → **GitHub Actions**
4. That's it! GitHub will automatically detect the workflow file

---

## Step 4: Wait for Deployment

1. Go to the **"Actions"** tab in your repository
2. You'll see a workflow running called "Deploy to GitHub Pages"
3. Wait for it to complete (usually 2-3 minutes)
4. Once complete, you'll see a ✅ green checkmark

---

## Step 5: Access Your Live Website! 🎉

Your website will be live at:

```
https://YOUR_USERNAME.github.io/borhan-sorkar-education/
```

**Replace `YOUR_USERNAME` with your actual GitHub username.**

---

## 🔄 Automatic Updates

Whenever you make changes and push to GitHub:

```bash
git add .
git commit -m "Your update message"
git push
```

GitHub Actions will **automatically rebuild and redeploy** your website!

---

## 🌟 Using a Custom Domain (Optional)

If you want a custom domain like `www.yoursite.com`:

### 1. Buy a Domain
- Purchase from [Namecheap](https://namecheap.com), [GoDaddy](https://godaddy.com), etc.

### 2. Configure DNS
Add these DNS records with your domain provider:

| Type | Host | Value |
|------|------|-------|
| A | @ | 185.199.108.153 |
| A | @ | 185.199.109.153 |
| A | @ | 185.199.110.153 |
| A | @ | 185.199.111.153 |
| CNAME | www | YOUR_USERNAME.github.io |

### 3. Add CNAME file
Create `public/CNAME` in your project:
```
www.yourdomain.com
```

### 4. Update vite.config.ts
```typescript
base: '/', // Remove the repository name
```

### 5. Enable in GitHub
1. Go to Settings → Pages
2. Under "Custom domain", enter your domain
3. Check "Enforce HTTPS"

---

## 🛠️ Troubleshooting

### Issue: Website shows 404 error

**Solution:**
- Make sure repository is **Public**
- Check that GitHub Actions completed successfully
- Wait 5-10 minutes after deployment
- Verify the URL is correct

### Issue: Styles/CSS not loading

**Solution:**
- Check `vite.config.ts` has correct `base` path
- Should match your repository name

### Issue: Images not showing

**Solution:**
- Use relative paths in your code
- Example: `./image.png` instead of `/image.png`

### Issue: Deployment failed

**Solution:**
1. Go to Actions tab
2. Click on the failed workflow
3. Check the error message
4. Common fixes:
   - Make sure `package.json` exists
   - Check Node.js version (should be 18+)

---

## 📱 Making Changes

To update your website:

1. Edit files locally
2. Save changes
3. Run:
```bash
git add .
git commit -m "Description of changes"
git push
```
4. GitHub will automatically redeploy!

---

## 💡 Tips

- **Test locally first**: Run `npm run dev` before pushing
- **Check build**: Run `npm run build` to ensure no errors
- **Use meaningful commit messages**: Helps track changes
- **Enable HTTPS**: Always use secure connection

---

## 📞 Need Help?

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [Vite Deployment Guide](https://vitejs.dev/guide/static-deploy.html#github-pages)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)

---

**🎉 Congratulations! Your website is now live on GitHub Pages!**
