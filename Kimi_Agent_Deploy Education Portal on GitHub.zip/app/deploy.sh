#!/bin/bash

# Borhan Sorkar Education Portal - Deployment Script
# GitHub Username: Borhansorkar

echo "🚀 Borhan Sorkar Education Portal - Deployment Script"
echo "======================================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# GitHub Configuration
USERNAME="Borhansorkar"
REPO_NAME="borhan-sorkar-education"
REPO_URL="https://github.com/$USERNAME/$REPO_NAME"
WEBSITE_URL="https://$USERNAME.github.io/$REPO_NAME/"

echo -e "${BLUE}📋 Configuration:${NC}"
echo "  GitHub Username: $USERNAME"
echo "  Repository: $REPO_NAME"
echo "  Repository URL: $REPO_URL"
echo "  Website URL: $WEBSITE_URL"
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo -e "${RED}❌ Git is not installed. Please install Git first.${NC}"
    echo "Download: https://git-scm.com/downloads"
    exit 1
fi

# Check if node is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed. Please install Node.js first.${NC}"
    echo "Download: https://nodejs.org/"
    exit 1
fi

echo -e "${GREEN}✅ Git and Node.js are installed${NC}"
echo ""

# Build the project
echo -e "${YELLOW}🔨 Building project...${NC}"
npm run build

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Build failed. Please fix errors and try again.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Build successful!${NC}"
echo ""

# Initialize git if not already
echo -e "${YELLOW}📦 Preparing Git repository...${NC}"

if [ ! -d ".git" ]; then
    git init
    echo -e "${GREEN}✅ Git repository initialized${NC}"
else
    echo -e "${BLUE}ℹ️ Git repository already exists${NC}"
fi

# Configure git (if not already set)
git config user.email "borhan@example.com" 2>/dev/null || true
git config user.name "Borhan Sorkar" 2>/dev/null || true

# Add all files
git add .

# Commit
echo -e "${YELLOW}💾 Committing changes...${NC}"
git commit -m "Deploy Borhan Sorkar Education Portal to GitHub Pages"

# Add remote
echo -e "${YELLOW}🔗 Connecting to GitHub...${NC}"
git remote remove origin 2>/dev/null
git remote add origin "$REPO_URL.git"

# Push to GitHub
echo -e "${YELLOW}📤 Pushing to GitHub...${NC}"
git branch -M main
git push -u origin main

if [ $? -ne 0 ]; then
    echo ""
    echo -e "${RED}❌ Push failed. Possible reasons:${NC}"
    echo "  1. Repository doesn't exist on GitHub"
    echo "  2. Authentication required"
    echo ""
    echo -e "${YELLOW}📋 Please create the repository first:${NC}"
    echo "  1. Go to: https://github.com/new"
    echo "  2. Repository name: $REPO_NAME"
    echo "  3. Make it Public"
    echo "  4. Click 'Create repository'"
    echo "  5. Then run this script again"
    echo ""
    echo -e "${BLUE}Or use this direct link:${NC}"
    echo "  https://github.com/new?name=$REPO_NAME&visibility=public"
    exit 1
fi

echo ""
echo -e "${GREEN}✅ Successfully pushed to GitHub!${NC}"
echo ""
echo -e "${BLUE}🌐 Your website will be live at:${NC}"
echo "  $WEBSITE_URL"
echo ""
echo -e "${YELLOW}📋 Next steps:${NC}"
echo "  1. Go to: https://github.com/$USERNAME/$REPO_NAME/settings/pages"
echo "  2. Under 'Source', select 'GitHub Actions'"
echo "  3. Wait 2-3 minutes for deployment"
echo "  4. Visit your live website!"
echo ""
echo -e "${GREEN}🎉 Done!${NC}"
