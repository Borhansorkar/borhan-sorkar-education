import { useEffect, useRef, useState } from 'react';
import { 
  Play, 
  BookOpen, 
  Scale, 
  Home, 
  Users, 
  Video, 
  Menu, 
  X,
  ChevronRight,
  Youtube,
  Facebook,
  Twitter,
  Instagram,
  Mail,
  MapPin,
  Clock,
  Eye,
  Heart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import './App.css';

// Video Data
const videos = [
  {
    id: 'ZQzR_CHp7qM',
    title: 'নতুন ডাবিং সূরা আল কদরের তাফসির',
    duration: '36:51',
    views: '1,234',
    category: 'কুরআন',
    thumbnail: 'https://img.youtube.com/vi/ZQzR_CHp7qM/maxresdefault.jpg'
  },
  {
    id: 'p-2sTwe95Gw',
    title: 'কিভাবে আল্লাহ সুবহানাহু তায়ালা আমাদের দোয়ার জবাব দেন',
    duration: '27:43',
    views: '892',
    category: 'ইসলামিক',
    thumbnail: 'https://img.youtube.com/vi/p-2sTwe95Gw/maxresdefault.jpg'
  },
  {
    id: 'n0QZPDer9rs',
    title: 'যেভাবে হিংসা আমাদের আমল গুলোকে ধ্বংস করে দেয়',
    duration: '23:21',
    views: '756',
    category: 'ইসলামিক',
    thumbnail: 'https://img.youtube.com/vi/n0QZPDer9rs/maxresdefault.jpg'
  },
  {
    id: 'ZW5EyLV4azc',
    title: 'বাংলাদেশের ইসলামি দল গুলোর ঐক্যবদ্ধ হওয়া জরুরী',
    duration: '0:09',
    views: '445',
    category: 'রাজনীতি',
    thumbnail: 'https://img.youtube.com/vi/ZW5EyLV4azc/maxresdefault.jpg'
  },
  {
    id: 'iWjDyJgobn8',
    title: 'আগামীর বাংলাদেশ ইসলামের বাংলাদেশ',
    duration: '0:09',
    views: '332',
    category: 'রাজনীতি',
    thumbnail: 'https://img.youtube.com/vi/iWjDyJgobn8/maxresdefault.jpg'
  },
  {
    id: 'yeTJzIQM9w0',
    title: 'দান শুধুমাত্র আল্লাহর উদ্যেশ্যে',
    duration: '0:20',
    views: '228',
    category: 'ইসলামিক',
    thumbnail: 'https://img.youtube.com/vi/yeTJzIQM9w0/maxresdefault.jpg'
  }
];

const categories = [
  {
    id: 'quran',
    title: 'আল কুরআন',
    titleEn: 'AL Quran',
    count: 12,
    icon: BookOpen,
    description: 'কুরআন তিলাওয়াত ও তাফসির',
    color: 'from-brand-blue to-blue-600',
    playlistId: 'PLG1d61u3j5yKZj0gxAZho1yXkLjVCLbqP'
  },
  {
    id: 'politics',
    title: 'রাজনীতি',
    titleEn: 'Politics',
    count: 7,
    icon: Scale,
    description: 'বাংলাদেশের রাজনৈতিক বিশ্লেষণ',
    color: 'from-brand-red to-red-600',
    playlistId: 'PLG1d61u3j5yKnl7b3jErfmerBaGvsnVBE'
  },
  {
    id: 'lifestyle',
    title: 'দৈনন্দিন জীবন',
    titleEn: 'Daily Life',
    count: 12,
    icon: Home,
    description: 'দৈনন্দিন জীবনের উপদেশ',
    color: 'from-brand-gold to-amber-500',
    playlistId: 'PLG1d61u3j5yKDYivMvknOAQaRcQxiPqH4'
  }
];

const stats = [
  { value: 103, suffix: '+', label: 'ভিডিও', labelEn: 'Videos' },
  { value: 3, suffix: '', label: 'ক্যাটাগরি', labelEn: 'Categories' },
  { value: 12, suffix: '+', label: 'কোর্স', labelEn: 'Courses' },
  { value: 211, suffix: '+', label: 'সাবস্ক্রাইবার', labelEn: 'Subscribers' }
];

function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState('সব');
  const [currentVideo, setCurrentVideo] = useState(videos[0]);
  const [counters, setCounters] = useState([0, 0, 0, 0]);
  const statsRef = useRef<HTMLDivElement>(null);
  const [statsVisible, setStatsVisible] = useState(false);

  // Scroll handler
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Intersection Observer for stats
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !statsVisible) {
          setStatsVisible(true);
        }
      },
      { threshold: 0.5 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, [statsVisible]);

  // Counter animation
  useEffect(() => {
    if (!statsVisible) return;

    const duration = 1500;
    const steps = 60;
    const interval = duration / steps;

    let step = 0;
    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const easeOut = 1 - Math.pow(1 - progress, 3);
      
      setCounters(stats.map(stat => Math.floor(stat.value * easeOut)));

      if (step >= steps) {
        clearInterval(timer);
        setCounters(stats.map(s => s.value));
      }
    }, interval);

    return () => clearInterval(timer);
  }, [statsVisible]);

  const filteredVideos = activeFilter === 'সব' 
    ? videos 
    : videos.filter(v => v.category === activeFilter);

  const filters = ['সব', 'কুরআন', 'রাজনীতি', 'ইসলামিক'];

  return (
    <div className="min-h-screen bg-brand-light font-bengali">
      {/* Navigation */}
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled 
            ? 'h-16 glass shadow-lg' 
            : 'h-20 bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full">
          <div className="flex items-center justify-between h-full">
            {/* Logo */}
            <a href="#" className="flex items-center gap-3 group">
              <div className="w-12 h-12 rounded-full bg-gradient-brand flex items-center justify-center text-white font-bold text-lg shadow-glow group-hover:scale-110 transition-transform duration-300">
                MBU
              </div>
              <span className={`font-display font-bold text-lg hidden sm:block transition-colors ${isScrolled ? 'text-brand-navy' : 'text-brand-navy'}`}>
                Borhan Sorkar
              </span>
            </a>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              {['হোম', 'কোর্সসমূহ', 'ভিডিও', 'সম্পর্কে'].map((item, i) => (
                <a 
                  key={item}
                  href={`#${['hero', 'courses', 'videos', 'about'][i]}`}
                  className="text-brand-navy/80 hover:text-brand-red font-medium underline-grow transition-colors"
                >
                  {item}
                </a>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden md:block">
              <Button 
                className="bg-gradient-brand text-white hover:opacity-90 magnetic-btn rounded-full px-6"
                onClick={() => window.open('https://youtube.com/@borhan_sorkar', '_blank')}
              >
                <Youtube className="w-4 h-4 mr-2" />
                সাবস্ক্রাইব
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden glass border-t">
            <div className="px-4 py-4 space-y-3">
              {['হোম', 'কোর্সসমূহ', 'ভিডিও', 'সম্পর্কে'].map((item, i) => (
                <a 
                  key={item}
                  href={`#${['hero', 'courses', 'videos', 'about'][i]}`}
                  className="block py-2 text-brand-navy font-medium"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
              <Button 
                className="w-full bg-gradient-brand text-white mt-4"
                onClick={() => window.open('https://youtube.com/@borhan_sorkar', '_blank')}
              >
                <Youtube className="w-4 h-4 mr-2" />
                সাবস্ক্রাইব
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="hero" className="relative min-h-screen flex items-center overflow-hidden pt-20">
        {/* Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-red-50 via-white to-blue-50 animate-gradient" />
        
        {/* Floating Particles */}
        <div className="particles">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                width: `${Math.random() * 15 + 5}px`,
                height: `${Math.random() * 15 + 5}px`,
                background: i % 2 === 0 ? '#DC2626' : '#1E40AF',
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${4 + Math.random() * 4}s`
              }}
            />
          ))}
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold text-brand-navy leading-tight animate-slide-up">
                  জ্ঞানের{' '}
                  <span className="text-gradient">সন্ধানে</span>
                </h1>
                <p className="text-lg sm:text-xl text-brand-navy/70 max-w-lg animate-slide-up" style={{ animationDelay: '0.2s' }}>
                  রাজনীতি, দৈনন্দিন জীবন, এআই প্রযুক্তি ও ইসলামিক শিক্ষার এক অনন্য প্ল্যাটফর্ম
                </p>
              </div>

              {/* Stats */}
              <div className="flex flex-wrap gap-6 animate-slide-up" style={{ animationDelay: '0.4s' }}>
                {stats.slice(0, 3).map((stat, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-lg bg-gradient-brand flex items-center justify-center">
                      {i === 0 ? <Video className="w-5 h-5 text-white" /> : 
                       i === 1 ? <BookOpen className="w-5 h-5 text-white" /> : 
                       <Users className="w-5 h-5 text-white" />}
                    </div>
                    <div>
                      <p className="font-bold text-brand-navy">{stat.value}{stat.suffix}</p>
                      <p className="text-sm text-brand-navy/60">{stat.label}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-wrap gap-4 animate-slide-up" style={{ animationDelay: '0.6s' }}>
                <Button 
                  size="lg"
                  className="bg-gradient-brand text-white magnetic-btn rounded-full px-8"
                  onClick={() => document.getElementById('courses')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  কোর্স দেখুন
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="border-2 border-brand-navy/20 text-brand-navy hover:bg-brand-navy/5 rounded-full px-8"
                  onClick={() => document.getElementById('player')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  <Play className="w-5 h-5 mr-2" />
                  ভিডিও প্লে করুন
                </Button>
              </div>
            </div>

            {/* Hero Image/Visual */}
            <div className="relative hidden lg:block">
              <div className="relative w-full aspect-square max-w-md mx-auto">
                {/* Main Circle */}
                <div className="absolute inset-0 rounded-full bg-gradient-brand opacity-10 animate-pulse-glow" />
                <div className="absolute inset-4 rounded-full bg-gradient-to-br from-red-100 to-blue-100 flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <div className="w-32 h-32 mx-auto rounded-full bg-gradient-brand flex items-center justify-center shadow-glow animate-float">
                      <span className="text-5xl font-bold text-white">MBU</span>
                    </div>
                    <div>
                      <p className="text-2xl font-display font-bold text-brand-navy">Mohammad</p>
                      <p className="text-xl font-display text-brand-navy/70">Borhan Uddin</p>
                      <p className="text-lg text-brand-gold font-medium">ETC</p>
                    </div>
                  </div>
                </div>
                
                {/* Floating Cards */}
                <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-card p-4 animate-float-delayed">
                  <BookOpen className="w-8 h-8 text-brand-blue" />
                  <p className="text-sm font-medium mt-2">কুরআন</p>
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-card p-4 animate-float" style={{ animationDelay: '2s' }}>
                  <Scale className="w-8 h-8 text-brand-red" />
                  <p className="text-sm font-medium mt-2">রাজনীতি</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Course Categories */}
      <section id="courses" className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-brand-navy mb-4">
              কোর্স <span className="text-gradient">ক্যাটাগরি</span>
            </h2>
            <p className="text-brand-navy/60 text-lg">
              আপনার পছন্দের বিষয় বেছে নিন
            </p>
          </div>

          {/* Categories Grid */}
          <div className="grid md:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <div
                key={category.id}
                className="group relative bg-white rounded-3xl shadow-card overflow-hidden card-3d hover:shadow-card-hover transition-all duration-500"
                style={{ animationDelay: `${index * 0.15}s` }}
              >
                {/* Gradient Header */}
                <div className={`h-32 bg-gradient-to-r ${category.color} relative overflow-hidden`}>
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute top-4 right-4 w-20 h-20 rounded-full bg-white/20" />
                    <div className="absolute bottom-4 left-4 w-12 h-12 rounded-full bg-white/10" />
                  </div>
                  <div className="absolute bottom-4 left-6">
                    <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center">
                      <category.icon className="w-8 h-8 text-white" />
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 pt-12">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-display font-bold text-brand-navy">
                      {category.title}
                    </h3>
                    <span className="px-3 py-1 rounded-full bg-brand-light text-sm font-medium text-brand-navy/70">
                      {category.count} ভিডিও
                    </span>
                  </div>
                  <p className="text-brand-navy/60 text-sm mb-4">
                    {category.description}
                  </p>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-between group/btn hover:bg-gradient-brand hover:text-white transition-all"
                    onClick={() => window.open(`https://youtube.com/playlist?list=${category.playlistId}`, '_blank')}
                  >
                    প্লেলিস্ট দেখুন
                    <ChevronRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Videos */}
      <section id="videos" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-12">
            <div>
              <h2 className="text-3xl sm:text-4xl font-display font-bold text-brand-navy mb-2">
                জনপ্রিয় <span className="text-gradient">ভিডিও</span>
              </h2>
              <p className="text-brand-navy/60">
                সর্বাধিক দেখা কন্টেন্ট
              </p>
            </div>

            {/* Filter Tabs */}
            <div className="flex flex-wrap gap-2">
              {filters.map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    activeFilter === filter
                      ? 'bg-gradient-brand text-white'
                      : 'bg-brand-light text-brand-navy/70 hover:bg-brand-navy/10'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {/* Videos Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVideos.map((video, index) => (
              <div
                key={video.id}
                className="group bg-white rounded-2xl shadow-card overflow-hidden hover:shadow-card-hover hover:-translate-y-2 transition-all duration-500 cursor-pointer"
                onClick={() => {
                  setCurrentVideo(video);
                  document.getElementById('player')?.scrollIntoView({ behavior: 'smooth' });
                }}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Thumbnail */}
                <div className="relative aspect-video overflow-hidden">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${video.id}/hqdefault.jpg`;
                    }}
                  />
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  
                  {/* Play Button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <div className="w-14 h-14 rounded-full bg-brand-red flex items-center justify-center shadow-glow transform scale-75 group-hover:scale-100 transition-transform">
                      <Play className="w-6 h-6 text-white ml-1" />
                    </div>
                  </div>

                  {/* Duration Badge */}
                  <div className="absolute bottom-3 right-3 px-2 py-1 rounded-md bg-black/80 text-white text-xs font-medium">
                    {video.duration}
                  </div>

                  {/* Category Badge */}
                  <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-white/90 text-xs font-medium text-brand-navy">
                    {video.category}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <h3 className="font-display font-semibold text-brand-navy line-clamp-2 group-hover:text-brand-red transition-colors">
                    {video.title}
                  </h3>
                  <div className="flex items-center gap-4 mt-3 text-sm text-brand-navy/60">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {video.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {video.duration}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* YouTube Player Section */}
      <section id="player" className="py-20 bg-gradient-to-b from-brand-navy to-slate-800 relative overflow-hidden">
        {/* Background Glow */}
        <div className="absolute inset-0">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-red/20 rounded-full blur-[100px]" />
          <div className="absolute top-1/3 right-1/4 w-[400px] h-[400px] bg-brand-blue/20 rounded-full blur-[80px]" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">
              ভিডিও <span className="text-brand-gold">প্লেয়ার</span>
            </h2>
            <p className="text-white/60 text-lg">
              সরাসরি ইউটিউব থেকে দেখুন
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Player */}
            <div className="lg:col-span-2">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl animate-pulse-glow">
                <div className="aspect-video">
                  <iframe
                    src={`https://www.youtube.com/embed/${currentVideo.id}?autoplay=0&rel=0`}
                    title={currentVideo.title}
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-xl font-display font-bold text-white">
                  {currentVideo.title}
                </h3>
                <div className="flex items-center gap-4 mt-2 text-white/60">
                  <span className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    {currentVideo.views} views
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {currentVideo.duration}
                  </span>
                </div>
              </div>
            </div>

            {/* Playlist */}
            <div className="lg:col-span-1">
              <div className="bg-white/5 backdrop-blur rounded-2xl p-4 border border-white/10">
                <h3 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-brand-gold" />
                  প্লেলিস্ট
                </h3>
                <div className="space-y-3 max-h-[400px] overflow-y-auto">
                  {videos.map((video) => (
                    <div
                      key={video.id}
                      className={`flex gap-3 p-3 rounded-xl cursor-pointer transition-all ${
                        currentVideo.id === video.id
                          ? 'bg-white/10 border border-brand-gold/50'
                          : 'hover:bg-white/5'
                      }`}
                      onClick={() => setCurrentVideo(video)}
                    >
                      <div className="relative w-24 h-16 rounded-lg overflow-hidden flex-shrink-0">
                        <img
                          src={video.thumbnail}
                          alt={video.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${video.id}/hqdefault.jpg`;
                          }}
                        />
                        {currentVideo.id === video.id && (
                          <div className="absolute inset-0 bg-brand-red/80 flex items-center justify-center">
                            <Play className="w-5 h-5 text-white" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-medium line-clamp-2 ${
                          currentVideo.id === video.id ? 'text-brand-gold' : 'text-white'
                        }`}>
                          {video.title}
                        </p>
                        <p className="text-xs text-white/50 mt-1">{video.duration}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section ref={statsRef} className="py-20 bg-brand-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-brand-navy mb-4">
              আমাদের <span className="text-gradient">অর্জন</span>
            </h2>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="relative group"
              >
                <div className="text-center">
                  {/* Circle with animated border */}
                  <div className="relative w-32 h-32 mx-auto mb-4">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="#E2E8F0"
                        strokeWidth="8"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="url(#gradient)"
                        strokeWidth="8"
                        strokeLinecap="round"
                        strokeDasharray={`${2 * Math.PI * 45}`}
                        strokeDashoffset={statsVisible ? 0 : `${2 * Math.PI * 45}`}
                        className="transition-all duration-[1500ms] ease-out"
                        style={{ transitionDelay: `${index * 200}ms` }}
                      />
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#DC2626" />
                          <stop offset="100%" stopColor="#1E40AF" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-3xl font-bold text-brand-navy">
                        {counters[index]}{stat.suffix}
                      </span>
                    </div>
                  </div>
                  <p className="text-lg font-medium text-brand-navy">{stat.label}</p>
                  <p className="text-sm text-brand-navy/60">{stat.labelEn}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Image */}
            <div className="relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <div className="aspect-square bg-gradient-to-br from-red-100 via-white to-blue-100 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-40 h-40 mx-auto rounded-full bg-gradient-brand flex items-center justify-center shadow-glow mb-6">
                      <span className="text-6xl font-bold text-white">MBU</span>
                    </div>
                    <h3 className="text-2xl font-display font-bold text-brand-navy">
                      Mohammad Borhan Uddin
                    </h3>
                    <p className="text-brand-gold font-medium">ETC</p>
                  </div>
                </div>
              </div>
              {/* Decorative Elements */}
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-brand-red/10 rounded-full blur-xl" />
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-brand-blue/10 rounded-full blur-xl" />
            </div>

            {/* Content */}
            <div className="space-y-6">
              <h2 className="text-3xl sm:text-4xl font-display font-bold text-brand-navy">
                চ্যানেল <span className="text-gradient">সম্পর্কে</span>
              </h2>
              <p className="text-lg text-brand-navy/70 leading-relaxed">
                Mohammad Borhan Uddin ETC — একটি বহুমুখী ইউটিউব চ্যানেল যেখানে আপনি পাবেন 
                রাজনীতি, দৈনন্দিন জীবন, এআই প্রযুক্তি ও বাস্তবধর্মী ভাবনার সম্মিলন।
              </p>

              {/* Mission Points */}
              <div className="space-y-4">
                {[
                  { icon: BookOpen, text: 'ইসলামিক শিক্ষা প্রচার' },
                  { icon: Scale, text: 'রাজনৈতিক সচেতনতা' },
                  { icon: Video, text: 'প্রযুক্তি জ্ঞান' },
                  { icon: Heart, text: 'সামাজিক মূল্যবোধ' }
                ].map((item, index) => (
                  <div 
                    key={index}
                    className="flex items-center gap-4 p-4 rounded-xl bg-brand-light hover:bg-red-50 transition-colors group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-brand flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <item.icon className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-brand-navy font-medium">{item.text}</span>
                  </div>
                ))}
              </div>

              <Button 
                size="lg"
                className="bg-gradient-brand text-white magnetic-btn rounded-full px-8"
                onClick={() => window.open('https://youtube.com/@borhan_sorkar', '_blank')}
              >
                <Youtube className="w-5 h-5 mr-2" />
                চ্যানেল দেখুন
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter/CTA Section */}
      <section className="py-20 relative overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-brand" />
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC40Ij48Y2lyY2xlIGN4PSIzMCIgY3k9IjMwIiByPSIyIi8+PC9nPjwvZz48L3N2Zz4=')]" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/95 backdrop-blur-xl rounded-3xl p-8 sm:p-12 shadow-2xl">
            <div className="text-center mb-8">
              <h2 className="text-3xl sm:text-4xl font-display font-bold text-brand-navy mb-4">
                আমাদের সাথে <span className="text-gradient">যুক্ত থাকুন</span>
              </h2>
              <p className="text-brand-navy/60 text-lg">
                নতুন ভিডিও ও কোর্সের আপডেট পেতে সাবস্ক্রাইব করুন
              </p>
            </div>

            {/* Email Form */}
            <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-8">
              <Input
                type="email"
                placeholder="আপনার ইমেইল ঠিকানা"
                className="flex-1 h-14 px-6 rounded-full border-2 border-brand-navy/10 focus:border-brand-red"
              />
              <Button 
                size="lg"
                className="h-14 px-8 bg-gradient-brand text-white magnetic-btn rounded-full"
              >
                সাবস্ক্রাইব
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            {/* Social Links */}
            <div className="flex justify-center gap-4">
              {[
                { icon: Youtube, href: 'https://youtube.com/@borhan_sorkar', color: 'hover:bg-red-600' },
                { icon: Facebook, href: '#', color: 'hover:bg-blue-600' },
                { icon: Twitter, href: '#', color: 'hover:bg-sky-500' },
                { icon: Instagram, href: '#', color: 'hover:bg-pink-600' }
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-12 h-12 rounded-full bg-brand-light flex items-center justify-center text-brand-navy hover:text-white ${social.color} transition-all hover:scale-110`}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-brand-navy text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Top Border Animation */}
          <div className="h-1 bg-gradient-to-r from-brand-red via-brand-gold to-brand-blue rounded-full mb-12" />

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-12">
            {/* Brand */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-brand flex items-center justify-center text-white font-bold">
                  MBU
                </div>
                <div>
                  <p className="font-display font-bold">Borhan Sorkar</p>
                  <p className="text-sm text-white/60">জ্ঞানের সন্ধানে</p>
                </div>
              </div>
              <p className="text-white/60 text-sm">
                একটি বহুমুখী শিক্ষামূলক প্ল্যাটফর্ম যেখানে রাজনীতি, ইসলামিক শিক্ষা ও দৈনন্দিন জীবনের বিষয় নিয়ে আলোচনা করা হয়।
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-display font-bold text-lg mb-4">কুইক লিংক</h4>
              <ul className="space-y-3">
                {['হোম', 'কোর্সসমূহ', 'ভিডিও', 'সম্পর্কে'].map((item, i) => (
                  <li key={item}>
                    <a 
                      href={`#${['hero', 'courses', 'videos', 'about'][i]}`}
                      className="text-white/60 hover:text-brand-gold transition-colors flex items-center gap-2"
                    >
                      <ChevronRight className="w-4 h-4" />
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Categories */}
            <div>
              <h4 className="font-display font-bold text-lg mb-4">ক্যাটাগরি</h4>
              <ul className="space-y-3">
                {categories.map((cat) => (
                  <li key={cat.id}>
                    <a 
                      href={`https://youtube.com/playlist?list=${cat.playlistId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-white/60 hover:text-brand-gold transition-colors flex items-center gap-2"
                    >
                      <ChevronRight className="w-4 h-4" />
                      {cat.title}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-display font-bold text-lg mb-4">যোগাযোগ</h4>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-white/60">
                  <Mail className="w-5 h-5 text-brand-gold" />
                  contact@borhansorkar.com
                </li>
                <li className="flex items-center gap-3 text-white/60">
                  <MapPin className="w-5 h-5 text-brand-gold" />
                  ঢাকা, বাংলাদেশ
                </li>
                <li className="flex items-center gap-3 text-white/60">
                  <Youtube className="w-5 h-5 text-brand-gold" />
                  @borhan_sorkar
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom */}
          <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-white/60 text-sm">
              © 2025 Mohammad Borhan Uddin Etc. All rights reserved.
            </p>
            <p className="text-white/60 text-sm flex items-center gap-1">
              Made with <Heart className="w-4 h-4 text-brand-red fill-brand-red" /> in Bangladesh
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
